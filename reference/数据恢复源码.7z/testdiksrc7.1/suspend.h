void suspend_memory(j_common_ptr cinfo);
int resume_memory(j_common_ptr cinfo);
