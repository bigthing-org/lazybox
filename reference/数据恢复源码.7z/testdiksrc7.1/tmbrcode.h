#ifdef __cplusplus
extern "C" {
#endif

int write_MBR_code(disk_t *disk_car);

#ifdef __cplusplus
} /* closing brace for extern "C" */
#endif
